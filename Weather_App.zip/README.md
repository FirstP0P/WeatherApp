# React + Vite

This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react/README.md) uses [Babel](https://babeljs.io/) for Fast Refresh
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react-swc) uses [SWC](https://swc.rs/) for Fast Refresh
=======
# 🌤️ Weather App

A simple weather application built with React.js that fetches real-time weather data using the OpenWeather API.

🚀 Features <br>
✅ Search for weather by city name. <br>
✅ Display temperature, location, and weather description. <br>
✅ Show hourly and daily forecasts. <br>
✅ Use Material Symbols icons for UI enhancement. <br>
✅ Responsive design. <br>
